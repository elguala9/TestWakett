using Microsoft.EntityFrameworkCore;
using Rates.Infrastracture.Models.Rates;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddDbContext<RatesContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("RatesDb")));

// Repositories
builder.Services.AddScoped<IRateRepository, RateRepository>();

// Services
builder.Services.AddScoped<IRatesService, RatesService>();

// HttpClient for CoinMarketCap
builder.Services.AddHttpClient(); // or AddHttpClient("CoinMarketCap")

// Controllers
builder.Services.AddControllers();

builder.Services.AddHttpClient();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
